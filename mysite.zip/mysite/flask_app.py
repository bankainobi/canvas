import os
import json
from flask import Flask, render_template_string, request, redirect, url_for, session
from functools import wraps

# --- CONFIGURACIÓN DE LA APLICACIÓN ---
app = Flask(__name__)
app.secret_key = 'secret_key'

# Credenciales Admin General
ADMIN_USER = 'user'
ADMIN_PASS = 'passwd'

# Usuarios Privados
PRIVATE_USERS = {
    'user': 'passwd',
    'user': 'passwd',
    'user': 'passwd',
    'user': 'passwd'
}

# Archivo de base de datos
PAGES_FILE = 'pages.json'

# --- CONFIGURACIÓN VISUAL ---
THEME_COLORS = {
    'Drácula Cian': 'bg-cyan-600 hover:bg-cyan-500 border-cyan-500 text-white',
    'Drácula Rosa': 'bg-pink-600 hover:bg-pink-500 border-pink-500 text-white',
    'Drácula Verde': 'bg-emerald-600 hover:bg-emerald-500 border-emerald-500 text-white',
    'Drácula Amarillo': 'bg-yellow-500 hover:bg-yellow-400 border-yellow-400 text-black',
    'Drácula Púrpura': 'bg-purple-600 hover:bg-purple-500 border-purple-500 text-white',
}

SUBJECT_ICONS = {
    'Lengua': ['fa-solid fa-book-open', 'fa-solid fa-feather-pointed', 'fa-solid fa-comments'],
    'Mates': ['fa-solid fa-calculator', 'fa-solid fa-square-root-variable', 'fa-solid fa-chart-line'],
    'Historia': ['fa-solid fa-landmark', 'fa-solid fa-scroll', 'fa-solid fa-clock-rotate-left'],
    'Inglés': ['fa-solid fa-globe', 'fa-solid fa-headset', 'fa-solid fa-spell-check'],
    'Biología': ['fa-solid fa-dna', 'fa-solid fa-seedling', 'fa-solid fa-microscope'],
    'Física y Química': ['fa-solid fa-atom', 'fa-solid fa-flask', 'fa-solid fa-temperature-three-quarters'],
}

# --- PERSISTENCIA ---
def load_pages():
    if not os.path.exists(PAGES_FILE): return []
    try:
        with open(PAGES_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except json.JSONDecodeError: return []

def save_pages(pages):
    with open(PAGES_FILE, 'w', encoding='utf-8') as f: json.dump(pages, f, indent=4)

# --- DECORADORES ---
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('logged_in') != True:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# --- PLANTILLA BASE ---
BASE_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }} | GHOST-SHELL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-deep: #15161C; --bg-card: #1E1F29; --bg-input: #0F1014;
            --fg-text: #E2E2E2; --fg-muted: #8F92A8;
            --accent-cyan: #8BE9FD; --accent-pink: #FF79C6; --accent-purple: #BD93F9; --accent-green: #50FA7B;
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--bg-deep); color: var(--fg-text); font-size: 0.95rem; }
        .text-cyan { color: var(--accent-cyan); }
        .text-pink { color: var(--accent-pink); }
        .text-purple { color: var(--accent-purple); }
        .text-muted { color: var(--fg-muted); }

        .input-deep {
            background-color: var(--bg-input); border: 1px solid #2F3142; color: var(--fg-text);
            padding: 0.6rem 1rem; border-radius: 0.5rem; width: 100%; transition: all 0.2s ease; font-size: 0.9rem;
        }
        .input-deep:focus { outline: none; border-color: var(--accent-purple); box-shadow: 0 0 0 2px rgba(189, 147, 249, 0.15); }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent-purple) 0%, #9B6BDE 100%); color: #15161C;
            font-weight: 700; padding: 0.6rem 1.25rem; border-radius: 0.5rem; text-transform: uppercase;
            font-size: 0.85rem; letter-spacing: 0.05em; transition: transform 0.1s, box-shadow 0.2s; border: none; cursor: pointer;
        }
        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(189, 147, 249, 0.35); }

        .card {
            background-color: var(--bg-card); border: 1px solid #2F3142; border-radius: 0.75rem; transition: all 0.3s ease;
        }
        .card:hover { border-color: var(--accent-pink); transform: translateY(-2px); box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5); }

        .radio-icon-box {
            background-color: var(--bg-input); border: 1px solid #2F3142; border-radius: 0.5rem; transition: all 0.2s; cursor: pointer;
        }
        .radio-input:checked + .radio-icon-box {
            background-color: var(--accent-purple); border-color: var(--accent-purple); color: #15161C;
            box-shadow: 0 0 15px rgba(189, 147, 249, 0.4);
        }

        /* Estilo para el Modal */
        .modal-backdrop {
            background-color: rgba(0, 0, 0, 0.85);
            backdrop-filter: blur(4px);
        }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <div class="max-w-6xl mx-auto px-4 w-full py-8">
        <nav class="flex justify-between items-center py-3 mb-8 border-b border-[#2F3142]">
            <div class="flex items-center gap-3">
                <i class="fa-solid fa-ghost text-purple text-xl"></i>
                <h1 class="text-2xl font-bold tracking-tight text-white">GHOST<span class="text-purple">SHELL</span></h1>
            </div>
            <div class="flex items-center gap-4 text-sm font-medium">
                <!-- Link a Privado -->
                <a href="{{ url_for('private_zone') }}" class="text-muted hover:text-pink transition-colors">
                    {% if session.get('private_user') %}
                        <span class="text-pink">●</span> {{ session.get('private_user') }}
                    {% else %}
                        <i class="fa-solid fa-lock text-xs"></i> PRIVADO
                    {% endif %}
                </a>
                <span class="text-[#2F3142]">|</span>
                <!-- Link a Admin -->
                <a href="{{ url_for('admin') }}" class="text-muted hover:text-cyan transition-colors">
                    {% if session.get('logged_in') %}
                        <span class="text-green-400">●</span> ADMIN
                    {% else %}
                        LOGIN
                    {% endif %}
                </a>
                <!-- Botón de Salir (Global) -->
                {% if session.get('logged_in') or session.get('private_user') %}
                <a href="{{ url_for('logout') }}" class="text-red-400 hover:text-red-300 transition-colors ml-2">[ EXIT ]</a>
                {% endif %}
            </div>
        </nav>
        {% block content %}{% endblock %}
    </div>
</body>
</html>
"""

# --- RUTA PÚBLICA (INDEX) ---
INDEX_TEMPLATE = BASE_HTML_TEMPLATE.replace('{% block content %}{% endblock %}', """
{% block content %}
<main>
    <div class="flex items-center gap-2 mb-6">
        <span class="w-1 h-6 bg-cyan-400 rounded-full"></span>
        <h2 class="text-xl font-semibold text-white tracking-wide">MÓDULOS PÚBLICOS</h2>
    </div>

    {% set public_pages = pages | selectattr('is_private', 'false') | list %}

    {% if public_pages %}
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            {% for page in public_pages %}
            <div class="card overflow-hidden group relative">
                <a href="{{ url_for('show_page', page_slug=page.slug) }}" class="block h-full">
                    <div class="p-5 flex items-center gap-4 {{ page.color }}">
                        <div class="bg-black/20 w-10 h-10 rounded-lg flex items-center justify-center backdrop-blur-sm">
                            <i class="{{ page.icon }} text-lg"></i>
                        </div>
                        <div class="min-w-0">
                            <h3 class="text-lg font-bold truncate">{{ page.title }}</h3>
                            <p class="text-[0.7rem] uppercase tracking-wider opacity-80">{{ page.subject }}</p>
                        </div>
                    </div>
                    <div class="p-4 bg-[#1E1F29] border-t border-[#2F3142] flex justify-between items-center">
                        <span class="text-xs text-muted font-mono">STATUS: <span class="text-green-400">PUBLIC</span></span>
                        <i class="fa-solid fa-arrow-right text-muted group-hover:text-cyan transform group-hover:translate-x-1 transition-all text-sm"></i>
                    </div>
                </a>
            </div>
            {% endfor %}
        </div>
    {% else %}
        <div class="p-8 border border-dashed border-[#2F3142] rounded-xl text-center text-muted">
            NO DATA FOUND. ESPERANDO INYECCIÓN PÚBLICA.
        </div>
    {% endif %}
</main>
{% endblock %}
""")

@app.route('/')
def index():
    pages = load_pages()
    for p in pages:
        if 'is_private' not in p: p['is_private'] = False
    return render_template_string(INDEX_TEMPLATE, title='Inicio', pages=pages, url_for=url_for, session=session)

# --- VISTA DETALLE ---
PAGE_DETAIL_TEMPLATE = BASE_HTML_TEMPLATE.replace('{% block content %}{% endblock %}', """
{% block content %}
<main class="max-w-4xl mx-auto">
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl {{ page.color }} flex items-center justify-center shadow-lg shadow-purple-900/20">
                <i class="{{ page.icon }} text-xl"></i>
            </div>
            <div>
                <h2 class="text-2xl font-bold text-white leading-tight">{{ page.title }}</h2>
                <span class="text-xs font-mono text-cyan px-2 py-0.5 rounded bg-cyan-900/20 border border-cyan-900/30">{{ page.subject }}</span>
                {% if page.is_private %}
                    <span class="text-xs font-mono text-pink px-2 py-0.5 rounded bg-pink-900/20 border border-pink-900/30 ml-2">
                        <i class="fa-solid fa-lock"></i> PRIVADO
                    </span>
                {% endif %}
            </div>
        </div>
        <a href="{{ url_for('private_zone' if page.is_private else 'index') }}" class="btn-secondary">
            <i class="fa-solid fa-arrow-left mr-2"></i> VOLVER
        </a>
    </div>

    <div class="card p-1 bg-[#0F1014] border-purple-500/30 shadow-2xl shadow-purple-900/10">
        <div class="rounded-lg overflow-hidden bg-black">
            {{ page.embed_code|safe }}
        </div>
    </div>
</main>
{% endblock %}
""")

@app.route('/page/<page_slug>')
def show_page(page_slug):
    pages = load_pages()
    page = next((p for p in pages if p['slug'] == page_slug), None)
    if not page: return "404 Not Found", 404

    is_private = page.get('is_private', False)
    if is_private:
        current_user = session.get('private_user')
        is_admin = session.get('logged_in')
        allowed_users = page.get('allowed_users', [])
        if not is_admin and (not current_user or current_user not in allowed_users):
            return redirect(url_for('private_login'))

    return render_template_string(PAGE_DETAIL_TEMPLATE, title=page['title'], page=page, url_for=url_for, session=session)

# --- ADMIN LOGIN ---
LOGIN_TEMPLATE = BASE_HTML_TEMPLATE.replace('{% block content %}{% endblock %}', """
{% block content %}
<div class="max-w-sm mx-auto mt-12">
    <div class="card p-8 border-t-4 border-t-purple-500 shadow-2xl">
        <div class="text-center mb-6">
            <h2 class="text-xl font-bold text-white mb-1">ACCESO ROOT</h2>
            <p class="text-xs text-muted uppercase">Administración del Sistema</p>
        </div>
        {% if error %}
        <div class="mb-5 p-3 bg-red-900/20 border border-red-500/30 rounded text-red-400 text-xs text-center">{{ error }}</div>
        {% endif %}
        <form method="POST">
            <div class="mb-4">
                <label class="block text-xs font-bold text-muted mb-2 uppercase">Admin User</label>
                <input type="text" name="username" required class="input-deep">
            </div>
            <div class="mb-6">
                <label class="block text-xs font-bold text-muted mb-2 uppercase">Password</label>
                <input type="password" name="password" required class="input-deep">
            </div>
            <button type="submit" class="w-full btn-primary">CONECTAR ROOT</button>
        </form>
    </div>
</div>
{% endblock %}
""")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form.get('username') == ADMIN_USER and request.form.get('password') == ADMIN_PASS:
            session.clear()
            session['logged_in'] = True
            session['username'] = ADMIN_USER
            return redirect(url_for('admin'))
        return render_template_string(LOGIN_TEMPLATE, title='Login Admin', error='Credenciales Inválidas', url_for=url_for, session=session)
    return render_template_string(LOGIN_TEMPLATE, title='Login Admin', url_for=url_for, session=session)

# --- ADMIN PANEL ---
ADMIN_TEMPLATE = BASE_HTML_TEMPLATE.replace('{% block content %}{% endblock %}', """
{% block content %}
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Formulario -->
    <div class="lg:col-span-1">
        <div class="card p-6 bg-[#181920] border border-[#2F3142]">
            <h3 class="text-lg font-bold text-white mb-5 flex items-center gap-2">
                <i class="fa-solid fa-plus-circle text-purple"></i> GESTIÓN DE NODOS
            </h3>

            {% if message %}
            <div class="mb-4 p-3 bg-green-900/20 border border-green-500/30 rounded text-green-400 text-xs">{{ message }}</div>
            {% endif %}

            <form id="node-form" method="POST" action="{{ url_for('add_page') }}" class="space-y-4">
                <div>
                    <label class="block text-xs font-bold text-muted mb-1.5 uppercase">Título</label>
                    <input type="text" name="title" required class="input-deep" placeholder="Ej: Notas de Rafa">
                </div>

                <!-- FIX: Añadido id="subject" para que el script de iconos funcione -->
                <div>
                    <label class="block text-xs font-bold text-muted mb-1.5 uppercase">Asignatura</label>
                    <select id="subject" name="subject" required class="input-deep select-deep">
                        {% for subject in subject_icons.keys() %}
                            <option value="{{ subject }}">{{ subject }}</option>
                        {% endfor %}
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-bold text-muted mb-1.5 uppercase">Embed Code (HTML)</label>
                    <textarea name="embed_code" required class="input-deep h-24 font-mono text-xs resize-none" placeholder="<div style=...>...</div>"></textarea>
                </div>

                <div>
                    <label class="block text-xs font-bold text-muted mb-1.5 uppercase">Icono</label>
                    <div id="icon-container" class="grid grid-cols-3 gap-2"></div>
                    <input type="hidden" id="selected-icon" name="icon" required>
                </div>

                <div>
                    <label class="block text-xs font-bold text-muted mb-1.5 uppercase">Color</label>
                    <div class="grid grid-cols-5 gap-2">
                        {% for color_name, color_class in theme_colors.items() %}
                        <label class="cursor-pointer group relative">
                            <input type="radio" name="color" value="{{ color_class }}" required class="hidden peer" {% if loop.first %}checked{% endif %}>
                            <div class="w-8 h-8 rounded-full mx-auto border-2 border-[#2F3142] peer-checked:border-white transition-all {{ color_class.split(' ')[0] }}"></div>
                        </label>
                        {% endfor %}
                    </div>
                </div>

                <!-- CHECKBOX PRIVACIDAD (Trigger del Modal) -->
                <div class="p-4 bg-[#0F1014] rounded border border-[#2F3142] mt-4">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="is_private" id="check_private" class="accent-purple-500 w-4 h-4">
                        <span class="text-sm font-bold text-pink-400"><i class="fa-solid fa-lock"></i> Restringir Acceso (Privado)</span>
                    </label>
                </div>

                <!-- BOTÓN CON LÓGICA JS -->
                <button type="button" onclick="handleSave(event)" class="w-full btn-primary mt-4">GUARDAR NODO</button>

                <!-- MODAL DE SELECCIÓN DE USUARIOS (Oculto dentro del form para enviar datos) -->
                <div id="user-modal" class="hidden fixed inset-0 z-50 modal-backdrop flex items-center justify-center p-4">
                    <div class="bg-[#1E1F29] border-2 border-pink-500 rounded-xl shadow-2xl max-w-sm w-full p-6">
                        <h4 class="text-xl font-bold text-white mb-2 text-center">ACCESO RESTRINGIDO</h4>
                        <p class="text-xs text-muted text-center mb-6">Selecciona qué usuarios pueden desencriptar este nodo:</p>

                        <div class="grid grid-cols-2 gap-3 mb-6">
                            {% for user in private_users.keys() %}
                            <label class="flex items-center gap-3 cursor-pointer hover:bg-[#15161C] p-2 rounded border border-[#2F3142] transition">
                                <input type="checkbox" name="allowed_users" value="{{ user }}" class="accent-pink-500 w-4 h-4">
                                <span class="text-sm font-bold text-gray-300">{{ user }}</span>
                            </label>
                            {% endfor %}
                        </div>

                        <div class="flex gap-3">
                            <button type="button" onclick="closeModal()" class="flex-1 py-2 border border-[#2F3142] text-muted rounded hover:text-white hover:bg-[#2F3142] transition">CANCELAR</button>
                            <button type="button" onclick="confirmPrivateSave()" class="flex-1 py-2 bg-pink-600 text-white font-bold rounded hover:bg-pink-500 transition shadow-lg shadow-pink-900/50">CONFIRMAR</button>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </div>

    <!-- Lista -->
    <div class="lg:col-span-2">
        <div class="card p-6 min-h-full">
            <h3 class="text-lg font-bold text-white mb-5">INVENTARIO ({{ pages|length }})</h3>
            <div class="space-y-3">
                {% for page in pages %}
                <div class="flex items-center justify-between p-3 rounded-lg bg-[#15161C] border border-[#2F3142] hover:border-[#44475A] transition-colors">
                    <div class="flex items-center gap-3 overflow-hidden">
                        <div class="w-8 h-8 rounded flex items-center justify-center text-xs {{ page.color }}">
                             <i class="{{ page.icon }}"></i>
                        </div>
                        <div class="min-w-0">
                            <div class="flex items-center gap-2">
                                <p class="font-bold text-sm text-gray-200 truncate">{{ page.title }}</p>
                                {% if page.is_private %}
                                    <span class="text-[0.6rem] bg-pink-900/50 text-pink border border-pink-800 px-1 rounded">PRIVADO</span>
                                {% else %}
                                    <span class="text-[0.6rem] bg-green-900/50 text-green-400 border border-green-800 px-1 rounded">PÚBLICO</span>
                                {% endif %}
                            </div>
                            <p class="text-[0.7rem] text-muted truncate">
                                {% if page.is_private %}
                                    Acceso: {{ page.allowed_users | join(', ') }}
                                {% else %}
                                    {{ page.subject }}
                                {% endif %}
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center gap-3">
                        <a href="{{ url_for('show_page', page_slug=page.slug) }}" target="_blank" class="text-cyan hover:text-white"><i class="fa-solid fa-eye"></i></a>
                        <a href="{{ url_for('delete_page', page_slug=page.slug) }}" onclick="return confirm('¿Borrar?')" class="text-red-500 hover:text-red-400"><i class="fa-solid fa-trash"></i></a>
                    </div>
                </div>
                {% endfor %}
            </div>
        </div>
    </div>
</div>

<script>
    // Lógica de iconos
    const subjectIcons = {{ subject_icons | tojson }};
    const subjectSelect = document.getElementById('subject');
    const iconContainer = document.getElementById('icon-container');
    const selectedIconInput = document.getElementById('selected-icon');

    function renderIcons(subject) {
        iconContainer.innerHTML = '';
        const icons = subjectIcons[subject] || [];
        icons.forEach((iconClass, index) => {
            const label = document.createElement('label');
            label.className = 'cursor-pointer w-full';
            const radio = document.createElement('input');
            radio.type = 'radio'; radio.name = 'icon_temp'; radio.value = iconClass;
            radio.className = 'hidden radio-input';
            if (index === 0) { radio.checked = true; selectedIconInput.value = iconClass; }
            const div = document.createElement('div');
            div.className = 'radio-icon-box h-10 flex items-center justify-center text-muted';
            div.innerHTML = `<i class="${iconClass}"></i>`;
            radio.addEventListener('change', () => { if(radio.checked) selectedIconInput.value = iconClass; });
            label.append(radio, div);
            iconContainer.appendChild(label);
        });
    }

    if (subjectSelect) {
        subjectSelect.addEventListener('change', (e) => renderIcons(e.target.value));
        if (subjectSelect.value) renderIcons(subjectSelect.value);
    }

    // Lógica del Modal de Privacidad
    function handleSave(e) {
        e.preventDefault();
        const isPrivate = document.getElementById('check_private').checked;
        if (isPrivate) {
            document.getElementById('user-modal').classList.remove('hidden');
        } else {
            document.getElementById('node-form').submit();
        }
    }

    function confirmPrivateSave() {
        // Validar que al menos un usuario esté seleccionado (opcional)
        // document.getElementById('node-form').submit();
        const checks = document.querySelectorAll('input[name="allowed_users"]:checked');
        if (checks.length === 0) {
            alert("Selecciona al menos un usuario autorizado.");
            return;
        }
        document.getElementById('node-form').submit();
    }

    function closeModal() {
        document.getElementById('user-modal').classList.add('hidden');
    }
</script>
{% endblock %}
""")

@app.route('/admin')
@admin_required
def admin():
    pages = load_pages()
    for p in pages:
        if 'is_private' not in p: p['is_private'] = False

    return render_template_string(
        ADMIN_TEMPLATE, title='ADMIN', session=session,
        subject_icons=SUBJECT_ICONS, theme_colors=THEME_COLORS,
        private_users=PRIVATE_USERS,
        pages=pages, url_for=url_for, message=session.pop('message', None)
    )

@app.route('/add_page', methods=['POST'])
@admin_required
def add_page():
    title = request.form.get('title')
    embed_code = request.form.get('embed_code')
    subject = request.form.get('subject')
    icon = request.form.get('icon')
    color = request.form.get('color')

    is_private = request.form.get('is_private') == 'on'
    allowed_users = request.form.getlist('allowed_users')

    if not all([title, embed_code, subject, icon, color]):
        session['message'] = 'Faltan datos básicos.'
        return redirect(url_for('admin'))

    pages = load_pages()
    slug = title.lower().replace(' ', '-').replace('/', '')

    new_page = {
        'title': title,
        'embed_code': embed_code,
        'subject': subject,
        'icon': icon,
        'color': color,
        'slug': slug,
        'is_private': is_private,
        'allowed_users': allowed_users if is_private else []
    }

    pages.append(new_page)
    save_pages(pages)
    session['message'] = 'NODO GUARDADO'
    return redirect(url_for('admin'))

@app.route('/delete_page/<page_slug>')
@admin_required
def delete_page(page_slug):
    save_pages([p for p in load_pages() if p['slug'] != page_slug])
    session['message'] = 'ELIMINADO'
    return redirect(url_for('admin'))

# --- ZONA PRIVADA ---
PRIVATE_LOGIN_TEMPLATE = BASE_HTML_TEMPLATE.replace('{% block content %}{% endblock %}', """
{% block content %}
<div class="max-w-sm mx-auto mt-12">
    <div class="card p-8 border-t-4 border-t-pink-500 shadow-2xl">
        <div class="text-center mb-6">
            <i class="fa-solid fa-lock text-pink text-3xl mb-2"></i>
            <h2 class="text-xl font-bold text-white mb-1">ZONA PRIVADA</h2>
            <p class="text-xs text-muted uppercase">Acceso para Alumnos</p>
        </div>
        {% if error %}
        <div class="mb-5 p-3 bg-red-900/20 border border-red-500/30 rounded text-red-400 text-xs text-center">{{ error }}</div>
        {% endif %}
        <form method="POST">
            <div class="mb-4">
                <label class="block text-xs font-bold text-muted mb-2 uppercase">Nombre</label>
                <input type="text" name="p_username" required class="input-deep" placeholder="Ej: Rafa">
            </div>
            <div class="mb-6">
                <label class="block text-xs font-bold text-muted mb-2 uppercase">Contraseña</label>
                <input type="password" name="p_password" required class="input-deep">
            </div>
            <button type="submit" class="w-full btn-primary bg-gradient-to-r from-pink-600 to-purple-600 border-none">ENTRAR</button>
        </form>
    </div>
</div>
{% endblock %}
""")

PRIVATE_ZONE_TEMPLATE = BASE_HTML_TEMPLATE.replace('{% block content %}{% endblock %}', """
{% block content %}
<main>
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-2">
            <span class="w-1 h-6 bg-pink-500 rounded-full"></span>
            <h2 class="text-xl font-semibold text-white tracking-wide">MIS DOCUMENTOS PRIVADOS</h2>
        </div>
        <p class="text-sm text-pink font-bold">Hola, {{ session['private_user'] }}</p>
    </div>

    {% if pages %}
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            {% for page in pages %}
            <div class="card overflow-hidden border border-pink-500/30">
                <a href="{{ url_for('show_page', page_slug=page.slug) }}" class="block">
                    <div class="p-5 flex items-center gap-4 {{ page.color }}">
                        <div class="bg-black/20 w-10 h-10 rounded-lg flex items-center justify-center">
                            <i class="{{ page.icon }} text-lg"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold">{{ page.title }}</h3>
                            <p class="text-[0.7rem] uppercase opacity-80">Privado</p>
                        </div>
                    </div>
                    <div class="p-4 bg-[#1E1F29] flex justify-between items-center">
                        <span class="text-xs text-pink font-mono"><i class="fa-solid fa-lock"></i> SECURE</span>
                        <i class="fa-solid fa-arrow-right text-muted"></i>
                    </div>
                </a>
            </div>
            {% endfor %}
        </div>
    {% else %}
        <div class="p-10 border border-dashed border-pink-500/30 rounded-xl text-center text-muted">
            No tienes documentos privados asignados actualmente.
        </div>
    {% endif %}
</main>
{% endblock %}
""")

@app.route('/private_login', methods=['GET', 'POST'])
def private_login():
    if request.method == 'POST':
        user = request.form.get('p_username')
        pw = request.form.get('p_password')
        if user in PRIVATE_USERS and PRIVATE_USERS[user] == pw:
            session.clear()
            session['private_user'] = user
            return redirect(url_for('private_zone'))
        else:
            return render_template_string(PRIVATE_LOGIN_TEMPLATE, title='Login Privado', error='Credenciales Incorrectas', url_for=url_for, session=session)
    return render_template_string(PRIVATE_LOGIN_TEMPLATE, title='Login Privado', url_for=url_for, session=session)

@app.route('/private')
def private_zone():
    if session.get('logged_in'):
        return redirect(url_for('admin'))
    user = session.get('private_user')
    if not user:
        return redirect(url_for('private_login'))

    all_pages = load_pages()
    my_pages = [p for p in all_pages if p.get('is_private') and user in p.get('allowed_users', [])]

    return render_template_string(PRIVATE_ZONE_TEMPLATE, title='Zona Privada', pages=my_pages, url_for=url_for, session=session)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    if not os.path.exists(PAGES_FILE): save_pages([])
    app.run(debug=True)